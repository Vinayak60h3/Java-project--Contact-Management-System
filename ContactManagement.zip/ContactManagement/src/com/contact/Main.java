package com.contact;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); 

        ContactService contactService = new ContactService(); 


        while (true) {
            System.out.println("1. Add Contact");
            System.out.println("2. View Contacts");
            System.out.println("3. Search Contacts");
            System.out.println("4. Delete Contact");
            System.out.println("5. Update Contact");
            System.out.println("6. Exit");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    contactService.addContact();
                    break;
                case 2:
                    contactService.listContacts();
                    break;
                case 3:
                    contactService.searchContacts();
                    break;
                case 4:
                    contactService.deleteContact();
                    break;
                case 5:
                    contactService.updateContact();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid Choice Please Try Again...");
            }
        }
    }
}